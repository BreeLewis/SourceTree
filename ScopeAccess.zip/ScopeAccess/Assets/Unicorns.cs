﻿using UnityEngine;
using System.Collections;

public class Unicorns : MonoBehaviour 
{
	private int white = 2;
	private int black = 4;
	private Dragons myOtherClass;
	public int population = 8;
	public int grey = 4;
	public int brown = 4;
	
	private void Unicorn () 
	{
	 population = grey + brown;
	 Debug.Log ("population:" +population);
	}
	void start()
	{
	 myOtherClass = new Dragons();
	 myOtherClass.Eat(population, myOtherClass.food);
	}
	public void Eaten (int eaten) 
	{
	 int decline;
	 decline = eaten - population;
	 Debug.Log ("Death in the herd:" + decline);
	 
	}
}
