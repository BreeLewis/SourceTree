﻿using UnityEngine;
using System.Collections;

public class Dragons : MonoBehaviour 
{
	private int ruby = 2;
	public int eat = 2;
	private int gold = 4;
	private int silver =4;
	public int dragon = 8;
	private Unicorns myOtherClass;
	
	void Start()
	{
		myOtherClass = new Unicorns();
		myOtherClass.Eaten(eat, myOtherClass.Unicorn);
	}
	
		void Eat(int treasure,int food) 
	{
		dragon = treasure*food;
		Debug.Log (dragon);
	}
	
	void Update () 
	{
		Debug.Log ("Dragon poplulation:" + dragon);
	}
}
